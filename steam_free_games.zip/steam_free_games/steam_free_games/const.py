DOMAIN = "steam_free_games"
GIVEAWAYS_URL = "https://www.gamerpower.com/api/giveaways"
UPDATE_INTERVAL = 3600  # en secondes
